package com.kar.horoscope.world.service

interface CompatibilityService {
    fun getImages() : Array<Int>
    fun getNames() : Array<String>
}