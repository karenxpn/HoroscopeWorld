package com.kar.horoscope.world.models

class CompatibilityModel( var pair: String? = null, var text: String? = null)
