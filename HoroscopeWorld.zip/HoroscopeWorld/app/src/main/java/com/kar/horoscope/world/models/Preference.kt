package com.kar.horoscope.world.models

data class Preference ( val tag: String, val preference : Int )