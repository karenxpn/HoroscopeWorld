package com.kar.horoscope.world.models

class DayModel @JvmOverloads constructor(var date: String? = null, var text: String? = null)