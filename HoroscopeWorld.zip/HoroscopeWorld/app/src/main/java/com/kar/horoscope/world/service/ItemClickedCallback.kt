package com.kar.horoscope.world.service

interface ItemClickedCallback {
    fun itemClicked( name: String, image: Int )
}