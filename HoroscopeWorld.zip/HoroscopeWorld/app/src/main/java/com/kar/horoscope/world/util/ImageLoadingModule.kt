package com.kar.horoscope.world.util

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule


@GlideModule
class ImageLoadingModule : AppGlideModule()