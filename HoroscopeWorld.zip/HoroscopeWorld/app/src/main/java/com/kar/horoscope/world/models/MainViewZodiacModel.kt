package com.kar.horoscope.world.models

data class MainViewZodiacModel( val name: String, val image: Int )